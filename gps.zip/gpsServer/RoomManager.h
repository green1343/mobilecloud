#pragma once

#include <fstream>
#ifndef WIN32
#define WIN32
#endif
#include <winsock2.h>
#include <windows.h>
#include <process.h>
#include <winsock.h>
#include <hash_map>
#include <hash_set>

namespace Massacre{

#define ROOM_SIZE 500

using namespace std;

class Room;
class User;

class Room{
public:
	int index;
	hash_set<SOCKET> sockets;
	float minX, minY;
	float maxX, maxY;
	HANDLE hThread;

	Room();

public:
	static unsigned WINAPI HandleRoom(void * arg);

};

class User{
public:
	HANDLE mutex;
	Room * room;

	User(){
		room = NULL;
	}
	~User(){
	}
};

class RoomManager{

private:
	RoomManager();
	~RoomManager();

	static RoomManager * m_instance;

public:
	static RoomManager * get();
	static void init();

private:
	int m_roomCnt;
	hash_map<int, Room *> m_rooms;

public:
	Room * getRoomForNewUser(SOCKET socket);
	void eraseRoom(int index);
};


}