#pragma once

#include <string>
#include <tuple>
#include <vector>
#include <cstdlib>


namespace Massacre
{
/*
* read�� Command�� ���� �а� �ش� Ŭ������ �����Ͽ� ����
* write�� Getbyte�Լ� ȣ���Ͽ� �ٷ� write
*/

using namespace std;

enum PACKET
{
	// Mobile -> Server
	PACKET_GPS_REQUEST = 1,
	PACKET_GPS = 2,

	// Server -> Mobile
	PACKET_GPS_REQUEST_RETURN = 3,
};

typedef char BYTE;

class Packet_Command
{
private:
	short m_command;

public:
	int place;
	BYTE * buf;

protected:
	Packet_Command()
	{
		place = 0;
		m_command = 0;
	}

	Packet_Command(short command)
	{
		place = 0;
		m_command = command;
	}

public:
	Packet_Command(BYTE buf[])
	{
		place = 0;
		this->buf = buf;
		unpack(m_command);
	}

	short getCommand()
	{
		return m_command;
	}

	void setCommand(short command)
	{
		m_command = command;
	}

	virtual void GetBytes(BYTE buf[])
	{
		place = 0;
		this->buf = buf;
		pack(m_command);
	}

protected:
	void pack(bool value);
	void pack(short value);
	void pack(int value);
	void pack(long long value);
	void pack(float value);
	void pack(double value);
	void pack(string value);

	void unpack(bool &value);
	void unpack(short &value);
	void unpack(int &value);
	void unpack(long long &value);
	void unpack(float &value);
	void unpack(double &value);
	void unpack(string &value);
};

class GpsInfo{
public:
	long long time;
	double lat;
	double lng;
};

class Packet_GPS: public Packet_Command
{
public:
	GpsInfo info;


public:
	Packet_GPS() :
		Packet_Command()
	{
		setCommand(PACKET_GPS);
	}

public:
	Packet_GPS(BYTE buf[]) :
		Packet_Command(buf)
	{
		unpack(info.time);
		unpack(info.lat);
		unpack(info.lng);
	}

	virtual void GetBytes(BYTE buf[])
	{
		Packet_Command::GetBytes(buf);
		pack(info.time);
		pack(info.lat);
		pack(info.lng);
	}
};

class Packet_GPS_Request : public Packet_Command
{
public:


public:
	Packet_GPS_Request() :
		Packet_Command()
	{
		setCommand(PACKET_GPS_REQUEST);
	}

public:
	Packet_GPS_Request(BYTE buf[]) :
		Packet_Command(buf)
	{
	}

	virtual void GetBytes(BYTE buf[])
	{
		Packet_Command::GetBytes(buf);
	}
};

class Packet_GPS_Request_Return : public Packet_Command
{
public:
	vector<GpsInfo> list;


public:
	Packet_GPS_Request_Return() :
		Packet_Command()
	{
		setCommand(PACKET_GPS_REQUEST_RETURN);
	}

public:
	Packet_GPS_Request_Return(BYTE buf[]) :
		Packet_Command(buf)
	{
		int size;
		unpack(size);
		for (int i = 0; i < size; ++i){
			GpsInfo info;
			unpack(info.time);
			unpack(info.lat);
			unpack(info.lng);

			list.push_back(info);
		}
	}

	virtual void GetBytes(BYTE buf[])
	{
		Packet_Command::GetBytes(buf);
		pack((int)list.size());
		for (int i = 0; i < list.size(); ++i){
			GpsInfo info = list[i];
			pack(info.time);
			pack(info.lat);
			pack(info.lng);
		}
	}
};

}