package com.example.android.basicaccessibility;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import com.example.android.common.logger.Log;
import com.example.android.packet.Packet_GPS_Request;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

/**
 * Created by 초록 on 2015-06-12.
 */
public enum Manager {
    INSTANCE;

    public class GpsInfo {
        public long time;
        public double lat;
        public double lng;

        public GpsInfo(){}
    }

    public GpsInfo getNewGpsInfo(){return new GpsInfo();}

    Context m_context;
    ArrayList<GpsInfo> m_gps = new ArrayList<>();

    public ArrayList<GpsInfo> getAllGpsInfo(){return m_gps;}

    public void init(Context context)
    {
        m_context = context;

        setupGPS();

        Thread t = new Thread(new Runnable() {
            public void run() {
                while (!Thread.interrupted()) {
                    Network.INSTANCE.init();
                    Packet_GPS_Request p = new Packet_GPS_Request();
                    Network.INSTANCE.write(p);
                    break;
                }
            }
        });
        t.start();
    }

    public Context getContext(){
        return m_context;
    }

    public GpsInfo addGps(){
        GpsInfo t = new GpsInfo();
        t.time = System.currentTimeMillis();
        t.lat = m_location.getLatitude();
        t.lng = m_location.getLongitude();

        m_gps.add(t);

        return t;
    }


    LocationManager m_locManager = null;
    Location m_location = null;

    public Location getLocation(){return m_location;}

    public void setupGPS(){

        // Acquire a reference to the system Location Manager
        m_locManager = (LocationManager) m_context.getSystemService(Context.LOCATION_SERVICE);

        // GPS 프로바이더 사용가능여부
        boolean isGPSEnabled = m_locManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        // 네트워크 프로바이더 사용가능여부
        boolean isNetworkEnabled = m_locManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);

        Log.d("Main", "isGPSEnabled="+ isGPSEnabled);
        Log.d("Main", "isNetworkEnabled="+ isNetworkEnabled);

        LocationListener locationListener = new LocationListener() {
            public void onLocationChanged(Location location) {
                m_location = location;
            }

            public void onStatusChanged(String provider, int status, Bundle extras) {
            }

            public void onProviderEnabled(String provider) {
            }

            public void onProviderDisabled(String provider) {
            }
        };

        // Register the listener with the Location Manager to receive location updates
        m_locManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationListener);
        m_locManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
    }

    /**
     * 위도와 경도 기반으로 주소를 리턴하는 메서드
     */
    public String getGPSAddress(double lat, double lng) {      //gps_주소찾기.
        if(m_location == null)
            return null;

        String address = null;


        //위치정보를 활용하기 위한 구글 API 객체
        Geocoder geocoder = new Geocoder(m_context, Locale.getDefault());     //에러시, 여기확인

        //주소 목록을 담기 위한 HashMap
        List<Address> list = null;

        try {
            list = geocoder.getFromLocation(lat, lng, 1);
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (list == null) {
            Log.e("getAddress", "주소 데이터 얻기 실패");
            return null;
        }
        if (list.size() > 0) {
            Address addr = list.get(0);
            address = addr.getCountryName() + " "    //국가이름
                    + addr.getAdminArea() + " "      //도(경기도, 충청남도...) / 서울은 null값
                    // + addr.getPostalCode() + " "    //우편번호
                    + addr.getLocality() + " "       //시 이름
                    + addr.getThoroughfare() + " "   //동이름
                    + addr.getFeatureName();          //번지
        }

        return address;
    }

}


