package com.example.android.packet;

public class PACKET {

    // Mobile -> Server
    public final static int PACKET_GPS_REQUEST = 1;
    public final static int PACKET_GPS = 2;

    // Server -> Mobile
    public final static int PACKET_GPS_REQUEST_RETURN = 3;
}
