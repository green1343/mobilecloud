package com.example.android.packet;

import com.example.android.basicaccessibility.Manager;

public class Packet_GPS extends Packet_Command
{
    public Manager.GpsInfo info = Manager.INSTANCE.getNewGpsInfo();

    public Packet_GPS(){
        setCommand((short) PACKET.PACKET_GPS);
    }

    public Packet_GPS(byte[] buf){

        super(buf);

        info.time = unpackLong();
        info.lat = unpackDouble();
        info.lng = unpackDouble();
    }

    public void GetBytes(byte[] buf){

        super.GetBytes(buf);

        pack(info.time);
        pack(info.lat);
        pack(info.lng);
    }
}
