package com.example.android.basicaccessibility;

import android.os.Handler;
import android.os.Message;
import android.util.Pair;

import com.example.android.packet.PACKET;
import com.example.android.packet.Packet_Command;
import com.example.android.packet.Packet_GPS_Request_Return;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;

/**
 * Created by 초록 on 2015-10-05.
 */
public enum Network {
    INSTANCE;

    public static final int BUF_SIZE = 256;

    //final String SERVER = "192.168.0.11";
    final String SERVER = "54.186.195.189";

    final int PORT = 13431;
    final int TIMEOUT = 10000;
    public static final int BUFFERSIZE = 1024;

    Socket m_socket;
    private OutputStream m_outstream = null;
    private InputStream m_instream;
    private BufferedReader m_reader;
    private BufferedWriter m_writer;

    NetworkListener m_listener;

    int m_id;

    boolean m_bConnected;

    public boolean init(){

        try {
            m_socket = new Socket(SERVER, PORT);
            m_socket.setTcpNoDelay(true);
            //m_socket.setSoTimeout(TIMEOUT);

            //m_writer = new BufferedWriter(new OutputStreamWriter(m_socket.getOutputStream(), "UTF-8"));
            m_outstream = m_socket.getOutputStream();
            m_instream = m_socket.getInputStream();
            m_writer = new BufferedWriter(new OutputStreamWriter(m_socket.getOutputStream()));
            m_reader = new BufferedReader(new InputStreamReader(m_socket.getInputStream()));

            m_listener = new NetworkListener(m_socket.getInputStream());
            m_listener.start();

            m_id = -1;

            m_bConnected = true;
            return true;

        } catch (IOException ex) {
            //System.err.println(ex);
            m_bConnected = false;
            return false;
        } finally { // dispose
            /*if (m_socket != null) {
                try {
                    m_socket.close();
                } catch (IOException ex) {
                    // ignore
                }
            }*/
        }
    }

    public int getID(){return m_id;}
    public void setID(int id){m_id = id;}

    public boolean isConnected(){return m_bConnected;}

    void write(byte [] b, int size)
    {
        if(m_outstream == null)
            return;

        /*String s = new String(b);
        PrintWriter out = new PrintWriter(m_writer, true);
        out.println(s);*/

        try {
            m_outstream.write(b, 0, size);
            m_outstream.flush();
        }
        catch (IOException ex) {
            //System.err.println(ex);
        }
    }

    void write(Packet_Command p)
    {
        if(m_bConnected == false)
            return;

        byte[] b = new byte[BUF_SIZE];
        p.GetBytes(b);
        Network.INSTANCE.write(b, p.place);
    }

    void destroy()
    {
        /*if(m_listener != null && m_listener.isAlive())
            m_listener.interrupt();
        m_listener.setKill();
        m_listener = null;*/
    }


    class NetworkListener extends Thread {

        private InputStream m_stream;
        private boolean m_kill = false;

        public NetworkListener(InputStream stream)
        {
            m_stream = stream;
        }

        /*****************************************************
         *		Main loop
         ******************************************************/

        @Override
        public void run()
        {
            while(!Thread.interrupted())
            {
                try {
                    byte stream[] = new byte[BUFFERSIZE];
                    int result = m_stream.read(stream);
                    if (result == -1) {
                        m_kill = true;
                        break;
                    }

                    while (true) {
                        Packet_Command cmd = new Packet_Command(stream); // new
                        int len = 0;

                        switch (cmd.getCommand()) {
                            case PACKET.PACKET_GPS_REQUEST_RETURN: {
                                Packet_GPS_Request_Return p = new Packet_GPS_Request_Return(stream);
                                Manager.INSTANCE.getAllGpsInfo().clear();
                                Manager.INSTANCE.getAllGpsInfo().addAll(p.list);

                                try {
                                    sleep(7000);
                                }catch(Exception e){}

                                Message msg = Message.obtain(GrouplistActivity.showGrouplist, 0 , 1 , 0);
                                GrouplistActivity.showGrouplist.sendMessage(msg);
                                break;
                            }
                            default:
                                break;
                        }

                        if(len > 0)
                            System.arraycopy(stream, len, stream, 0, BUFFERSIZE-len);
                        else
                            break;
                    }

                }catch(IOException ex){
                    //System.err.println(ex);
                }

                if(m_kill)
                    break;

            }	// End of while() loop

            // Finalize
            //finalizeThread();

        }	// End of run()

        void setKill(){
            m_kill = true;
        }
    }

}
