package com.example.android.packet;

import com.example.android.basicaccessibility.Manager;

import java.util.ArrayList;

public class Packet_GPS_Request_Return extends Packet_Command
{
    public ArrayList<Manager.GpsInfo> list = new ArrayList<>();

    public Packet_GPS_Request_Return(){
        setCommand((short) PACKET.PACKET_GPS_REQUEST_RETURN);
    }

    public Packet_GPS_Request_Return(byte[] buf){

        super(buf);

        int size = unpackInt();

        list.clear();
        for(int i=0; i<size; ++i) {
            Manager.GpsInfo info = Manager.INSTANCE.getNewGpsInfo();
            info.time = unpackLong();
            info.lat = unpackDouble();
            info.lng = unpackDouble();
            list.add(info);
        }
    }

    public void GetBytes(byte[] buf){

        super.GetBytes(buf);

        pack(list.size());
        for(Manager.GpsInfo info : list) {
            pack(info.time);
            pack(info.lat);
            pack(info.lng);
        }
    }
}
