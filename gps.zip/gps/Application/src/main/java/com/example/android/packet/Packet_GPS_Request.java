package com.example.android.packet;

public class Packet_GPS_Request extends Packet_Command
{

    public Packet_GPS_Request(){
        setCommand((short) PACKET.PACKET_GPS_REQUEST);
    }

    public Packet_GPS_Request(byte[] buf){

        super(buf);

    }

    public void GetBytes(byte[] buf){

        super.GetBytes(buf);

    }
}
