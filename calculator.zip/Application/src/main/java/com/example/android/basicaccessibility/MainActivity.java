/*
 * Copyright (C) 2013 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.android.basicaccessibility;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Basic activity class.
 *
 * <p>Responsible for rendering layout, and displaying some toasts to give buttons feedback.
 * There's nothing terribly interesting in this class. All the interesting stuff is in
 * res/layout/activity_main.xml and {@link DialView}.
 */
public class MainActivity extends Activity {

    /**
     * Standard onCreate() implementation. Sets R.layout.activity_main as the layout.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sample_main);
        findViewById(R.id.button0).setOnClickListener(mClickListener);
        findViewById(R.id.button1).setOnClickListener(mClickListener);
        findViewById(R.id.button2).setOnClickListener(mClickListener);
        findViewById(R.id.button3).setOnClickListener(mClickListener);
        findViewById(R.id.button4).setOnClickListener(mClickListener);
        findViewById(R.id.button5).setOnClickListener(mClickListener);
        findViewById(R.id.button6).setOnClickListener(mClickListener);
        findViewById(R.id.button6).setOnClickListener(mClickListener);
        findViewById(R.id.button7).setOnClickListener(mClickListener);
        findViewById(R.id.button8).setOnClickListener(mClickListener);
        findViewById(R.id.button9).setOnClickListener(mClickListener);
        findViewById(R.id.buttonAdd).setOnClickListener(mClickListener);
        findViewById(R.id.buttonSub).setOnClickListener(mClickListener);
        findViewById(R.id.buttonMultiply).setOnClickListener(mClickListener);
        findViewById(R.id.buttonDivide).setOnClickListener(mClickListener);
    }

    Button.OnClickListener mClickListener = new View.OnClickListener() {

        EditText textValue1;
        EditText textValue2;

        public void addNum(String num){
            if(textValue1.isFocused()){
                String s = textValue1.getText().toString();
                s += num;
                textValue1.setText(s);
            }
            else if(textValue2.isFocused()){
                String s = textValue2.getText().toString();
                s += num;
                textValue2.setText(s);
            }
        }

        public void onClick(View v) {
            textValue1=(EditText)findViewById(R.id.textValue1);
            textValue2=(EditText)findViewById(R.id.textValue2);
            TextView textResult=(TextView)findViewById(R.id.textResult);
            switch (v.getId()) {
                case R.id.button0: addNum("0"); break;
                case R.id.button1: addNum("1"); break;
                case R.id.button2: addNum("2"); break;
                case R.id.button3: addNum("3"); break;
                case R.id.button4: addNum("4"); break;
                case R.id.button5: addNum("5"); break;
                case R.id.button6: addNum("6"); break;
                case R.id.button7: addNum("7"); break;
                case R.id.button8: addNum("8"); break;
                case R.id.button9: addNum("9"); break;
                case R.id.buttonAdd:{
                        String s1 = textValue1.getText().toString();
                        String s2 = textValue2.getText().toString();
                        float result = Float.valueOf(s1) + Float.valueOf(s2);
                        textResult.setText(String.valueOf(result));
                    }
                    break;
                case R.id.buttonSub:{
                        String s1 = textValue1.getText().toString();
                        String s2 = textValue2.getText().toString();
                        float result = Float.valueOf(s1) - Float.valueOf(s2);
                        textResult.setText(String.valueOf(result));
                    }
                    break;
                case R.id.buttonMultiply:{
                        String s1 = textValue1.getText().toString();
                        String s2 = textValue2.getText().toString();
                        float result = Float.valueOf(s1) * Float.valueOf(s2);
                        textResult.setText(String.valueOf(result));
                    }
                    break;
                case R.id.buttonDivide:{
                        String s1 = textValue1.getText().toString();
                        String s2 = textValue2.getText().toString();
                        float result = Float.valueOf(s1) / Float.valueOf(s2);
                        textResult.setText(String.valueOf(result));
                    }
                    break;
            }
        }
    };
}
